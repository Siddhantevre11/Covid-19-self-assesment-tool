The "Rajam-Urban-Rural-Data.xlsx" is a data from pogiri PHC.

The "DATASET34733-5.py" is to test all 5 classification algorithms on dataset.

The "GUI-ML2.py" is python based GUI intrface for recommended system.
